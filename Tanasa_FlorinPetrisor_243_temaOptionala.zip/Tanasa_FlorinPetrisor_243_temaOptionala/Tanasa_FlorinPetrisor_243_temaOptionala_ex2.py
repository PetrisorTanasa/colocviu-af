
pPos = (1, 1)
cPos = (5, 4)
# forest = [
#     [1, 0, 0],
#     [0, 2, 0],
#     [0, 3, 4]
# ]
forest = [
    [0, 0, 0, 5, 6],
    [7, 7, 1, 1, 1],
    [1, 1, 1, 3, 1],
    [1, 1, 2, 2, 1],
    [0, 0, 9, 0, 0],
    [0, 0, 0, 0, 9]
]

directions = [
    [1, 0],
    [0, 1],
    [-1, 0],
    [0, -1]
]


def bt(forest, pos, target, spent, res, seen):
    if pos[0] == target[0] and pos[1] == target[1]:
        if spent < res[0]:
            res[0] = spent
        return

    for direction in directions:
        nextRow = pos[0] + direction[0]
        nextCol = pos[1] + direction[1]
        if nextRow >= 0 and nextCol >= 0 and nextRow < len(forest) and nextCol < len(forest[nextRow]) and ((nextRow, nextCol) not in seen.keys()
                                                                                                           or seen[(nextRow, nextCol)] is False):
            seen[(nextRow, nextCol)] = True
            if forest[nextRow][nextCol] != forest[pos[0]][pos[1]]:
                bt(forest, (nextRow, nextCol), target, spent+1, res, seen)
            else:
                bt(forest, (nextRow, nextCol), target, spent, res, seen)
            seen[(nextRow, nextCol)] = False


def solution(forest, pPos, cPos):
    res = [len(forest) * len(forest[0])]

    bt(forest, pPos, cPos, 0, res, {})
    return res[0]-1

print(solution(forest, pPos, cPos))