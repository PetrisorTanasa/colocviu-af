n = 4
connections = [[0, 1], [1, 2], [2, 0], [1, 3]]


def makeList(connections, n):
    list = []
    for i in range(0, n):
        subList = []
        for con in connections:
            if con[0] == i:
                subList.append(con[1])
            elif con[1] == i:
                subList.append(con[0])
        list.append(subList)
    return list


list = makeList(connections, n)


def dfs(edge, seen, node, list):
    if node in seen.keys():
        return
    seen[node] = True
    for j in list[node]:
        if node != edge[0] or j != edge[1]:
            dfs(edge, seen, j, list)


def solution(list):
    res = []
    for i in range(0, len(list)):
        for j in range(0, len(list[i])):
            if list[i][j] > i:
                edge = (i, list[i][j])
                seen = {}
                dfs(edge, seen, i, list)
                for k in range(0, n):
                    if k not in seen.keys():
                        res.append(edge)
                        break
    return res


arr = solution(list)
print(arr)