directions = [
    [1, 0],
    [0, 1],
    [-1, 0],
    [0, -1]
]

def solution(grid):
    max = 0
    for i in range(0, len(grid)):
        for j in range(0, len(grid[i])):
            if grid[i][j] == 1:
                pos = (i, j)
                queue = [pos]
                size = 0
                while len(queue):
                    size = size + 1
                    pos = queue.pop(0)
                    row = pos[0]
                    col = pos[1]
                    for k in directions:
                        nextRow = row + k[0]
                        nextCol = col + k[1]
                        if nextRow >= 0 and nextCol >= 0 and nextRow < len(grid) and nextCol < len(grid[nextRow]) and grid[nextRow][nextCol] == 1:
                            grid[nextRow][nextCol] = 2
                            queue.append((nextRow, nextCol))
                if max < size:
                    max = size
    return islands




print(solution(grid))