
n = 6
edges = [
    [1, 2],
    [1, 3],
    [1, 6],
    [2, 5],
    [3, 5],
    [5, 6],
    [5, 4]
]
start = 1
finish = 4


def makeList(n, edges):
    list = []
    list.append([])
    for i in range(1, n+1):
        subList = []
        for edge in edges:
            if edge[0] == i:
                subList.append(edge[1])
        list.append(subList)
    return list


def dfs(list, node, target, res, subArr, seen):
    if node == target:
        if len(res) == 0:
            res.append(subArr[-len(subArr)::1])
        else:
            if len(subArr) < len(res[0]):
                res.clear()
                res.append(subArr[-len(subArr)::1])
            elif len(subArr) == len(res[0]):
                res.append(subArr[-len(subArr)::1])
        return

    for nextNode in list[node]:
        if nextNode not in seen.keys() or seen[nextNode] == False:
            seen[nextNode] = True
            subArr.append(nextNode)
            dfs(list, nextNode, target, res, subArr, seen)
            subArr.pop(len(subArr)-1)
            seen[nextNode] = False

    return res


def solution(n, edges, start, finish):
    list = makeList(n, edges)
    res = []
    dfs(list, start, finish, res, [], {})

    seen = {}
    arr = []
    for i in res:
        for j in i:
            if j not in seen.keys():
                seen[j] = True
                arr.append(j)
    return arr

print(solution(n, edges, start, finish))