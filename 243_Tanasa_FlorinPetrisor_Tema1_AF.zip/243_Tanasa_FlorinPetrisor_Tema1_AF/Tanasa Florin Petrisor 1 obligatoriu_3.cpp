class Solution {
public:
    std::vector<std::unordered_map<int, bool>> makeList(int numCourses, std::vector<std::vector<int>> preqs){
        std::vector<std::unordered_map<int, bool>> list;

        for(int i=0; i<numCourses; i++){
            std::unordered_map<int, bool> subMap;
            for(int j=0; j<preqs.size(); j++){
                if(preqs[j][0] == i){
                    subMap[preqs[j][1]] = true;
                }
            }
            list.push_back(subMap);
        }
        return list;
    }

    void bt(std::vector<std::unordered_map<int, bool>> list, std::vector<int> subarray, std::vector<std::vector<int>>& ans, int n,                  std::unordered_map<int, bool>& seen){
        if(ans.size()) return;

        for(int k=subarray.size()-1; k>=0; k--){
            for (auto& c: list[subarray[k]]) {
                if(seen.find(c.first) == seen.end()  seen[c.first] == false) return;
            }
        }

        if(subarray.size() == n){
            ans.push_back(subarray);
            return;
        }

        for(int j=0; j<n; j++){
            if(seen.find(j) == seen.end()  seen[j] == false){
                seen[j] = true;
                subarray.push_back(j);
                bt(list, subarray, ans, n, seen);
                subarray.pop_back();
                seen[j] = false;
            }
        }
    }

    std::vector<int> findOrder(int numCourses, std::vector<std::vector<int>>& prerequisites) {
        std::vector<std::unordered_map<int, bool>> list = makeList(numCourses, prerequisites);

        std::unordered_map<int, bool> seen;
        std::vector<std::vector<int>> ans;

        bt(list, {}, ans, numCourses, seen);

        std::vector<int> res = {};

        return ans.size() ? ans[0] : res;
    }
};
