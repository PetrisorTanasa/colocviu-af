def solution(N, M, P, edges):
    list = []
    list.append([])
    for i in range(1, N+1):
        subarray = []
        for j in edges:
            if j[0] == i:
                subarray.append(j[1])
        list.append(subarray)
    sir = [P[0]]
    while len(sir):
        ok = 0
        if len(P) == 0:
            break
        for i in range(0, len(sir)):
            if sir[i] == P[0]:
                varf = sir.pop(i)
                P.pop(0)
                ok = 1
                break
        if ok == 0:
            break
        urmVarfuri = list[varf]
        for i in urmVarfuri:
            sir.append(i)

    if len(P) == 0:
        return 1
    return 0

firstLine = input().split(" ")
N = int(firstLine[0]);
M = int(firstLine[1]);
P = input().split(" ")
edges = []
Pprim = []
for i in range(len(P)):
    Pprim.append(int(P[i]))
for i in range(M):
    line = input().split(" ")
    subArray = [int(line[0]),int(line[1])]
    edges.append(subArray)

print(solution(N, M, Pprim, edges))