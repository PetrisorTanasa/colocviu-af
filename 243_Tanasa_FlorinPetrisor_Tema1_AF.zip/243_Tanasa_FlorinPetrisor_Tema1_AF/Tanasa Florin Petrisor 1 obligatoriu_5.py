control = [8, 9]
edges = [
    [9, 11], [1, 2], [1, 3], [1, 4], [2, 5], [2, 9], [3, 5], [3, 7], [5, 7], [6, 7], [6, 8], [4, 6],
]


def makeList(edges, n):
    list = []
    list.append([])
    for i in range(1, n+1):
        subarray = []
        for edge in edges:
            if edge[0] == i:
                subarray.append(edge[1])
            elif edge[1] == i:
                subarray.append(edge[0])
        list.append(subarray)

    return list


def dfs(list, arr, start, node, target, distance, seen):
    if node == target[0] or node == target[1]:
        if distance <= arr[start]:
            seen[start] = True
            arr[start] = distance
            return

    for j in list[node]:
        if j not in seen.keys() or seen[j] == False:
            seen[j] = True
            dfs(list, arr, start, j, target, distance+1, seen)
            seen[j] = False


def solution(edges, control):
    nodes = max(max(edges))
    list = makeList(edges, nodes)

    arr = [nodes] * nodes
    arr.insert(0, 0)

    for i in range(1, nodes+1):
        dfs(list, arr, i, i, control, 0, {})

    return arr

print(solution(edges, control))