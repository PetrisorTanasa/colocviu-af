def solution(N, M, P, edges):
    list = []
    list.append([])
    for i in range(1, N+1):
        subarray = []
        for j in edges:
            if j[0] == i:
                subarray.append(j[1])
        list.append(subarray)
    sir = [P[0]]
    while len(sir):
        ok = 0
        if len(P) == 0:
            break
        print(sir, P)
        for i in range(0, len(sir)):
            if sir[i] == P[0]:
                varf = sir.pop(i)
                P.pop(0)
                ok = 1
                break
        if ok == 0:
            break
        urmVarfuri = list[varf]
        for i in urmVarfuri:
            sir.append(i)

    print(P)
    if len(P) == 0:
        return 1
    return 0

print(solution(4, 3, [1, 2, 4, 3], [[1, 2], [2, 3], [3, 4]]))