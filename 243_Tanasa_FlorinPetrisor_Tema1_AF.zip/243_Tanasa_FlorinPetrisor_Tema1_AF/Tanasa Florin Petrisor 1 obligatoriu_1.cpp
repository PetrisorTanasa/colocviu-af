#include <vector>
#include <unordered_map>


std::unordered_map<int, std::unordered_map<int, bool>> makeMap(int n, std::vector<std::vector<int>> dislikes){

    std::unordered_map<int, std::unordered_map<int, bool>> map;

    for(int i=1; i<=n; i++){
        std::unordered_map<int, bool> subMap;
        std::vector<int> arr;
        for(int j=0; j<dislikes.size(); j++){
            if(dislikes[j][0] == i) arr.push_back(dislikes[j][1]);
        }

        for(int k=1; k<=n; k++){
            bool found = false;
            for(int j=0; j<arr.size(); j++){
                if(k!=i && arr[j] == k){
                    found = true;
                    break;
                }
            }
            if(found == false) subMap[k] = true;
        }

        map[i] = subMap;
    }
    return map;
}
[9:24 PM]
bool bt(std::vector<std::vector<int>>& groups, int i, int n, std::unordered_map<int, std::unordered_map<int, bool>> map){

    for(int k=0; k<groups[0].size(); k++){
        for(int z=k+1; z<groups[0].size(); z++){
            if(map[groups[0][k]].find(groups[0][z]) == map[groups[0][k]].end()) return false;
        }
    }
    for(int k=0; k<groups[1].size(); k++){
        for(int z=k+1; z<groups[1].size(); z++){
            if(map[groups[1][k]].find(groups[1][z]) == map[groups[1][k]].end()) return false;
        }
    }
    if(i==n+1){
        return true;
    }

    for(int j=i; j<=n; j++){
        groups[0].push_back(j);
        if(bt(groups, j+1, n, map) && groups[0].size() + groups[1].size() == n){
            return true;
        }
        groups[0].pop_back();

        groups[1].push_back(j);
        if(bt(groups, j+1, n, map) && groups[0].size() + groups[1].size() == n){
            return true;
        }
        groups[1].pop_back();
    }

    return false;
}

bool possibleBipartition(int n, std::vector<std::vector<int>>& dislikes) {
    std::unordered_map<int, std::unordered_map<int, bool>> map = makeMap(n, dislikes);

    std::vector<std::vector<int>> groups;
    groups.push_back({}); groups.push_back({});
    return bt(groups, 1, n, map);
}

int main() {
    std::vector<std::vector<int>> def = {{1, 2}, {2, 3}, {3, 4}, {4, 5}, {1, 5}};
    std::cout<<possibleBipartition(5, def);
    return 0;
}
