# Rezolvarea acestei probleme consta in utilizarea algoritmului BFS si a algoritmului de flux maxim. Matricea
# de capacitate este inițializată cu valori citite din input, iar apoi se face un apel la functia bfs() pentru a
# determina daca exista un drum de la sursa la destinatie. Daca exista, se actualizeaza fluxul si matricea de capacitate
# in functie de drumul gasit. Procesul se repeta pana cand nu mai exista drumuri de capacitate maxima.
# Complexitatea algoritmului: O(n * m^2), posibil O(n^3)?.

n = int(input())
destinatie = 2 * n + 1
matricePrim = [[0 for _ in range(destinatie + 1)] for _ in range(destinatie + 1)]
pozitii = [0] * (n + 2)

listaParinti = [-1] * (2 * n + 2)
listaVizitat = [0] * (2 * n + 2)
rezultat = []


def bfs():
    global matriceCapacitate, listaParinti, listaVizitat
    listaVizitat = [0] * (2 * n + 2)
    listaParinti = [-1] * (2 * n + 2)

    coada = [0]
    listaVizitat[0] = 1
    listaParinti[0] = -1

    while coada:
        nodCurent = coada.pop(0)

        if nodCurent == 2 * n + 1:
            return True

        # Verific daca exista un drum nevizitat si cu capacitate mai mare decat 0
        for nodUrmator in range(1, 2 * n + 2):
            if not listaVizitat[nodUrmator] and matriceCapacitate[nodCurent][nodUrmator] > 0:
                listaParinti[nodUrmator] = nodCurent
                listaVizitat[nodUrmator] = 1
                coada.append(nodUrmator)
    return False


matriceCapacitate = [[0 for _ in range(2 * n + 2)] for _ in range(2 * n + 2)]

for i in range(1, n + 1):
    numere = input().split()
    for j in range(1, n + 1):
        matriceCapacitate[i][n + j] = int(numere[j - 1])
        if matriceCapacitate[i][n + j]:
            matricePrim[i][n + j] = 1

for index in range(1, n + 1):
    matriceCapacitate[0][index] = 1
    matriceCapacitate[n + index][2 * n + 1] = 1

fluxMax = 0
while bfs():
    for index in range(1, n + 1):
        if matriceCapacitate[n + index][destinatie] > 0 and listaVizitat[n + index]:
            flux = 100000
            listaParinti[destinatie] = n + index
            nodCurent = destinatie

            # Actualizez fluxul in functie de muchiile din graf
            while nodCurent != 0:
                flux = min(flux, matriceCapacitate[listaParinti[nodCurent]][nodCurent])
                nodCurent = listaParinti[nodCurent]
            if flux:
                nodCurent = destinatie

            # Actualizez matricea de capacitate
            while nodCurent != 0:
                index = listaParinti[nodCurent]
                matriceCapacitate[index][nodCurent] -= flux
                matriceCapacitate[nodCurent][index] += flux
                nodCurent = listaParinti[nodCurent]

            fluxMax += flux

for index in range(1, n + 1):
    pozitii[index] = index

vecini = [0] * (n + 1)

for index in range(1, n + 1):
    for jndex in range(1, n + 1):
        if matriceCapacitate[index][n + jndex] == 0 and matricePrim[index][n + jndex] == 1:
            vecini[index] = jndex

if fluxMax != n:
    print(-1)
else:
    for index in range(1, n + 1):
        # Verific daca pozitia nodului index s-a modificat
        if vecini[index] != pozitii[index]:
            jndex = 1
            # Caut pozitia vecinului nodului "index"
            while pozitii[jndex] != vecini[index]:
                jndex += 1
            # Afisez mutarea efectuata
            print(f"R {pozitii[index]} {pozitii[jndex]}")
            aux = pozitii[index]
            pozitii[index] = pozitii[jndex]
            pozitii[jndex] = aux