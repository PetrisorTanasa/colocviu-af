#complexitate O(m)
#idee: se incepe cu un nod cu grad impar, daca exista, sau cu orice nod cu grad par si se face parcurgere pe
#lant/ciclu eulerian.

class Solution:
    def validArrangement(pairs):
        graph = dict()  # se face graful orientat
        outDegree = dict()  # <- retine pentru fiecare nod gradul de iesire
        inDegree = dict()  # <- retine pentru fiecare nod gradul de intrare
        for elem in pairs:
            if elem[0] not in graph:
                graph[elem[0]] = [elem[1]]
            else:
                graph[elem[0]].append(elem[1])
            if elem[0] not in outDegree:
                outDegree[elem[0]] = 1
            else:
                outDegree[elem[0]] += 1
            if elem[1] not in inDegree:
                inDegree[elem[1]] = 1
            else:
                inDegree[elem[1]] += 1

        start = pairs[0][0]  # se poate pune orice nod ca start in cazul in care este ciclu eulerian

        for elem in outDegree:
            if elem not in inDegree:
                if outDegree[elem] == 1:
                    start = elem
                    break
            if outDegree[elem] - inDegree[elem] == 1: #daca este lant eulerian, nodul de start va fi unul cu
                start = elem                          #care are cu o iesire mai mult decat intrari
                break

        drum = []
        stiva = []
        stiva.append(start)
        while (stiva):
            while graph[stiva[-1]]:
                stiva.append(graph[stiva[-1]].pop())  #se face parcurgerea pe lant/ciclu eulerian
                if (stiva[-1]) not in graph:
                    break
            drum.append(stiva.pop())
        return [[drum[-i - 1], drum[-i - 2]] for i in range(len(drum) - 1)]


# print(Solution.validArrangement([[5, 1], [4, 5], [11, 9], [9, 4]]))
# print(Solution.validArrangement([["a", "a"], ["a", "a"], ["a", "a"]]))

n, k = [int(x) for x in input().split()]

l = []


if k != 1:
    for i in range(n):
        readString = input()
        l.append([readString[:-1], readString[1:]])
    try:
        sol = Solution.validArrangement(l)
        solution = sol[0][0]+sol[0][1][-1] + "".join([x[1][-1] for x in sol[1:]])
        if len(solution) != n + k - 1:
            print(-1)
        else:
            print(solution)
    except:
        print(-1)
else:
    for i in range(n):
        readString = input()
        l.append(readString)
    print("".join(l))