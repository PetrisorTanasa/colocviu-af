win = set([])
loss = set([])
draw = set([])


def try_eval(nr):
    # lines
    if nr[0] == nr[0+1] and nr[0+1] == nr[0+2]:
        if nr[0] == '0':
            return -1
        return 1
    if nr[3] == nr[3+1] and nr[3+1] == nr[3+2]:
        if nr[3] == '0':
            return -1
        return 1
    if nr[6] == nr[6+1] and nr[6+1] == nr[6+2]:
        if nr[6] == '0':
            return -1
        return 1
    # col
    if nr[0] == nr[3] and nr[3] == nr[6]:
        if nr[0] == '0':
            return -1
        return 1
    if nr[1] == nr[1+3] and nr[1+3] == nr[1+6]:
        if nr[1] == '0':
            return -1
        return 1
    if nr[2] == nr[2+3] and nr[2+3] == nr[2+6]:
        if nr[2] == '0':
            return -1
        return 1
    # diagonals
    if nr[0] == nr[4] and nr[4] == nr[8]:
        if nr[4] == '0':
            return -1
        return 1
    if nr[2] == nr[4] and nr[4] == nr[6]:
        if nr[2] == '0':
            return -1
        return 1
    return 0


def place_in_bucket(nr, e):
    if e == 1:
        win.add(nr)
    elif e == -1:
        loss.add(nr)
    else:
        draw.add(nr)


def evall(nr, x, o):
    if nr in win:
        return 1
    if nr in loss:
        return -1
    if nr in draw:
        return 0

    full = 1
    all_returns = -2 if not x > o else 3
    for i, ch in enumerate(nr):
        if ch == '.':
            full = 0
            copy_nr = nr

            if x > o:
                copy_nr = copy_nr[:i] + '0' + copy_nr[i + 1:]
                rec_val = evall(copy_nr, x, o + 1)
                all_returns = min(all_returns, rec_val)

            else:
                copy_nr = copy_nr[:i] + 'X' + copy_nr[i + 1:]
                rec_val = evall(copy_nr, x + 1, o)
                all_returns = max(all_returns, rec_val)

            # place_in_bucket(nr, rec_val)

    if full:
        fin = try_eval(nr)
        place_in_bucket(nr, fin)
        return fin
    return all_returns


# file = open('.in')
file = open('xsizero.in')
endme = open('xsizero.out','w')
testul = 0
while 1 :
    testul +=1
    o = 0
    x = 0
    val = ''
    val += file.readline().replace('\n', '')
    val += file.readline().replace('\n', '')
    val += file.readline().replace('\n', '')
    if val == '':
        break

    for j in val:
        if j == 'X':
            x += 1
        if j == '0':
            o += 1


    if abs(x-o) >= 2:
        endme.write(f"Testul #{testul}: invalid\n")
        continue
    test = evall(val, x, o)
    if test == 1:
        endme.write(f"Testul #{testul}: win\n")
    elif test == -1:
        endme.write(f"Testul #{testul}: lose\n")
    else:
        endme.write(f"Testul #{testul}: draw\n")