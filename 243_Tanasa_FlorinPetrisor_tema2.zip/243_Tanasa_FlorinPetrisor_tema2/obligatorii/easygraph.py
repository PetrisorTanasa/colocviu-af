class Solution(object):
    def bt(self, l, i, suma, r, v, s):
        r.append(suma)
        n = l[i]
        for j in range(0, len(n)):
            if n[j] not in s.keys() or s[n[j]] == False:
                s[n[j]] = True
                self.bt(l, n[j], suma+v[n[j]], r, v, s)
                s[n[j]] = False

    def sol(self, n, m, v, e):
        l = []

        for i in range(0, len(e)):
            for j in range(0, len(e[i])):
                e[i][j] = e[i][j]-1

        for i in range(0, n):
            sl = []
            for j in range(0, len(e)):
                if e[j][0] == i:
                   sl.append(e[j][1])
                elif e[j][1] == i:
                    sl.append(e[j][0])
            l.append(sl)
        print(l)

        r = []
        for i in range(0, len(l)):
            self.bt(l, i, v[i], r, v, {i: True})

        print(r)
        if len(r) == 0:
            return -1
        return max(r)


s = Solution()
print(s.sol(4, 3, [-3, -1, 15, 5], [[1, 3], [3, 2], [2, 4]]))