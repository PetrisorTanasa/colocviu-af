cuvinte = ["martian","care","este","sinonim","ana","case","apa","arbore","partial","minim"]
multimi = [[x] for x in cuvinte]

def LevenshteinDistance(cuv1,cuv2,lungime1,lungime2):
    if(lungime1==0):
        return lungime2
    if(lungime2==0):
        return lungime1
    if(cuv1[lungime1 - 1] == cuv2[lungime2 - 1]):
        return LevenshteinDistance(cuv1,cuv2,lungime1 - 1,lungime2 - 1)
    return 1 + min(LevenshteinDistance(cuv1,cuv2,lungime1,lungime2 - 1),min(LevenshteinDistance(cuv1,cuv2,lungime1 - 1,lungime2),LevenshteinDistance(cuv1,cuv2,lungime1 - 1,lungime2 - 1)))

distante = []

for i in range(len(cuvinte)):
    for j in range(i,len(cuvinte)):
        dist = LevenshteinDistance(cuvinte[i],cuvinte[j],len(cuvinte[i]),len(cuvinte[j]))
        distante.append([cuvinte[i],cuvinte[j],dist])

nrCuv = int(input("Introduceti numarul de clustere: "))

distante = sorted(distante, key = lambda x : x[2])

for i in range(len(distante) - nrCuv):
    indice1 = -1
    indice2 = -2
    for j in range(len(multimi)):
        if(multimi[j][0] == distante[i][0] or distante[i][0] in multimi[j]):
            multime1 = multimi[j].copy()
            indice1 = j
        if(multimi[j][0] == distante[i][1] or distante[i][1] in multimi[j]):
            multime2 = multimi[j].copy()
            indice2 = j
    if multime1 != multime2 and indice1 != -1 and indice2 != -1:
        for x in multime2:
            multimi[indice1].append(x)
        multimi.remove(multime2)
        if(len(multimi) == nrCuv):
            break
for i in multimi:
    print(i)
dif_min = 999
for i in range(len(multimi)):
    for j in range(i+1,len(multimi)):
        for x in multimi[i]:
            for y in multimi[j]:
                LevenshteinDistanta = LevenshteinDistance(x,y,len(x),len(y))
                if(LevenshteinDistanta < dif_min):
                    dif_min = LevenshteinDistanta
print(dif_min)