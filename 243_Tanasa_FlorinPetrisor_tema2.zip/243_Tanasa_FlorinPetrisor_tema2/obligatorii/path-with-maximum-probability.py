class Solution(object):
    def bt(self, l, i, target, r, res, seen):
        if i == target:
            res.append(r)
            print(res)
            return

        print(i)

        next = l[i]["n"]
        s = l[i]["s"]
        for j in range(0, len(next)):
            if next[j] not in seen.keys() or seen[next[j]] == False:
                seen[next[j]] = True
                self.bt(l, next[j], target, r * s[j], res, seen)
                seen[next[j]] = False

    def maxProbability(self, n, edges, succProb, start, end):
        l = []

        for i in range(0, n):
            sl = {
                "n": [],
                "s": []
            }
            for j in range(0, len(edges)):
                if edges[j][0] == i:
                    sl["n"].append(edges[j][1])
                    sl["s"].append(succProb[j])
                if edges[j][1] == i:
                    sl["n"].append(edges[j][0])
                    sl["s"].append(succProb[j])
            l.append(sl)
        print(l)
        arr = []
        self.bt(l, start, end, 1, arr, {})
        print("arr: ", arr)
        if len(arr) == 0:
            return 0
        return max(arr)