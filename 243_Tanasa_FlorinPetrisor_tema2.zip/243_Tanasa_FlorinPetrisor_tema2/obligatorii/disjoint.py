n = int(input("N="))
m = int(input("M="))

M = [
    [1, 1, 2],
    [1, 3, 4],
    [2, 1, 3],
    [2, 1, 2],
    [1, 1, 3],
    [2, 1, 4]
]

alist = [[]]

for i in range(1, n+1):
    alist.append([])
    
for l in M:
    if l[0] == 1:
        for i in range(len(alist)):
            if len(alist[i]) > 0:
                if alist[i][0] == l[1]:
                    alist[i][0] = l[2]
        if len(alist[l[2]]) == 0:
            alist[l[2]].append(l[1])
        else:
            alist[l[2]][0] = l[1]
    else:
        if len(alist[l[2]]):
            el = alist[l[2]][0]
            ok = 0
            while True:
                if el == l[1]:
                    print("DA")
                    ok = 1
                    break
                if len(alist[el]):
                    el = alist[el][0]
                else:
                    break
            if ok == 0:
                print("NU")
        else:
            print("NU")

print(alist)