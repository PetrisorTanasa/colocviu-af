# n = int(input("n="))
# m = int(input("m="))
# k = int(input("k="))
#
# L = [int(x) for x in input("Fortarete=").split()]
# D = []
# for i in range(m):
#     dl = [int(x) for x in input("Drum: ").split()]
#     D.append(dl)
n = 8
m = 9
k = 2
L = [2, 5]
D = [
    [1, 3, 6],
    [1, 5, 3],
    [1, 6, 1],
    [2, 3, 9],
    [5, 6, 5],
    [6, 8, 7],
    [3, 6, 2],
    [4, 7, 1000],
    [2, 8, 5]
]

def makeList(L, D):
    lista = [[]]

    for i in range(1, n+1):
        obj = {
            "type": "",
            "nodes": []
        }
        if i in L:
            obj["type"] = "Fort"
        else:
            obj["type"] = "Catun"
        for d in D:
            sa = []
            if i in d:
                if d[0] == i:
                    sa.append(d[1])
                    sa.append(d[2])
                elif d[1] == i:
                    sa.append(d[0])
                    sa.append(d[2])
                obj["nodes"].append(sa)
        lista.append(obj)
    return lista


def bt(lista, node, seen, arr, lungime):
    if lista[node]["type"] == "Fort":
        arr.append({"n": node, "l": lungime})
        # return

    for j in range(0, len(lista[node]["nodes"])):
        k = lista[node]["nodes"]
        # print(k[j])
        if len(k[j]):
            if k[j][0] not in seen.keys() or seen[k[j][0]] == False:
                seen[k[j][0]] = True
                # print("BLABLA: ", lista[node]["nodes"], k[j][0])
                bt(lista, k[j][0], seen, arr, lungime+k[j][1])
                seen[k[j][0]] = False


def solutie(L, D):
    lista = makeList(L, D)

    res = [0] * n
    res.append(0)
    print(res)
    for i in range(1, len(lista)):
        if lista[i]["type"] == "Catun":
            arr = []
            seen = {}
            seen[i] = True
            bt(lista, i, seen, arr, 0)
            print(arr)
            min2 = -1000
            min5 = -1000
            for obj in arr:
                if obj["n"] == 2:
                    if min2 < 0:
                        min2 = obj["l"]
                    else:
                        if min2 > obj["l"]:
                            min2 = obj["l"]
                if obj["n"] == 5:
                    if min5 < 0:
                        min5 = obj["l"]
                    else:
                        if min5 > obj["l"]:
                            min5 = obj["l"]
            if min2 < min5:
                res[i] = 2
            elif min5 < min2:
                res[i] = 5
    del res[0]
    return res
print(solutie(L, D))