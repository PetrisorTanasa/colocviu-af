import math

N = 2
M = 2
C = [
    [0, 0],
    [10, 11]
]
B = [
    [10, 0],
    [0, 10]
]


def solution(C, B, N, M):
    group = {}
    nr = 0
    for c in C:
        group[nr] = {
            'group': nr,
            'powered': 1
        }
        nr += 1

    for b in B:
        group[nr] = {
            'group': nr,
            'powered': 0
        }
        nr += 1
    print("GROUPS:", group)
    list = C + B
    print("LIST:", list)

    distances = {}
    for i in range(0, len(list)):
        for j in range(i+1, len(list)):
            dist = math.sqrt((list[j][0]-list[i][0])(list[j][0]-list[i][0]) + (list[j][1]-list[i][1])(list[j][1]-list[i][1]))
            distances[(i, j)] = dist
    print("DISTANCES:", distances)

    sortedDist = sorted(distances, key=distances.get)
    print("SORTEDDIST: ", sortedDist)
    edges = {}

    for i in range(0, len(sortedDist)):
        edge = sortedDist[i]
        print(edge)
        if group[edge[0]]["group"] != group[edge[1]]["group"]:
            if group[edge[0]]["powered"] == 1 and group[edge[1]]["powered"] == 0:
                group[edge[1]]["group"] = group[edge[0]]["group"]
                group[edge[1]]["powered"] = 1
                edges[edge] = distances[edge]
            elif group[edge[1]]["powered"] == 1 and group[edge[0]]["powered"] == 0:
                group[edge[0]]["group"] = group[edge[1]]["group"]
                group[edge[0]]["powered"] = 1
                edges[edge] = distances[edge]

    sum = 0
    for dist in edges.values():
        sum += dist
    return sum

print(solution(C, B, N, M))