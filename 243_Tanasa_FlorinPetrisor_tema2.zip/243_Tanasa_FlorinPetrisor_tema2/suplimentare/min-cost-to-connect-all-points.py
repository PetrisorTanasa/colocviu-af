class Solution:
    def minCostConnectPoints(self, points: List[List[int]]) -> int:

        # pick points[0] 
        # update all nodes with distance from the current one, enqueue them
        # if all visited, it means all edges in the MST are the shortest to connect all, then stop

        n = len(points)
        res = 0
        MST = set()
        q = [(0, points[0][0], points[0][1], 0)]
        while q and len(MST) < n:
            dist, x1, y1, idx = heappop(q)
            if idx in MST: continue
            MST.add(idx)
            res += dist
            for i in range(n):
                if i not in MST: 
                    x2, y2 = points[i]
                    heappush(q, (abs(x1-x2) + abs(y1-y2), x2, y2, i))
            
        return res