class Solution:
    def findCheapestPrice(self, n: int, flights: List[List[int]], src: int, dst: int, k: int) -> int:
        cost = [float("inf")] * n
        cost[src] = 0
        for i in range(k+1):
            aux = cost.copy()
            for source, destination, costul in flights:
                if cost[source] == float("inf"):
                    continue
                if cost[source] + costul < aux[destination]:
                    aux[destination] = cost[source] + costul
            cost = aux
        if cost[destination] == float("inf") or cost[destination] == 0:
            return -1
        return cost[destination]