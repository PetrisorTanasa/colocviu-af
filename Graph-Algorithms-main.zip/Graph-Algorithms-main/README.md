# Algoritmi Fundamentali
Profesor: Marinescu Ghemeci Ruxandra

1. Parcurgeri
- [x] Breadth First Search
- [ ] Depth First Search
- [x] Havel Hakimi
- [ ] Kosaraju Algorithm
- [ ] Adjacency List
- [ ] Adjacency Matrix
- [ ] Topological Sort
2. Arbori partiali de cost minim
- [ ] Prim Algorithm
- [ ] Kruskal Algorithm
3. Drumuri minime
- [ ] Dijkstra Algorithm
- [ ] Ford Warshall Algorithm
4. Fluxuri in retele
- [ ] Edmonds Karp Algorithm