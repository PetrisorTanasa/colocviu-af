from collections import defaultdict
from queue import Queue

with open("maxflow.txt", 'r') as fin:
    nr_noduri, nr_muchii = map(int, fin.readline().split())
    start = 1
    end = nr_noduri
    graph = defaultdict(list)
    capacity = defaultdict(dict)
    parent = [None] * (nr_noduri + 1)
    for _ in range(nr_muchii):
        x, y, c = map(int, fin.readline().split())
        graph[x].append(y)
        capacity[x][y] = c


def bfs():
    visited = [False] * (nr_noduri + 1)
    q = Queue(maxsize=nr_noduri)
    q.put(start)
    visited[start] = True
    while not q.empty():
        node = q.get()
        for neighbour in graph[node]:
            if not visited[neighbour] and capacity[node][neighbour] > 0:
                q.put(neighbour)
                visited[neighbour] = True
                parent[neighbour] = node
    return True if visited[end] else False


def edmonds_karp():
    max_flow = 0

    while bfs():
        path_flow = float("inf")
        nod = end

        while nod != start:
            path_flow = min(path_flow, capacity[parent[nod]][nod])
            nod = parent[nod]

        max_flow += path_flow
        nod = end

        while nod != start:
            tata = parent[nod]
            capacity[tata][nod] -= path_flow
            nod = tata
    ####   modificare exercitiul b
    print("Taietura minima este:")
    visited = [False] * (nr_noduri + 1)
    q = Queue(maxsize=nr_noduri)
    q.put(start)
    print(start)
    visited[start] = True
    while not q.empty():
        node = q.get()
        for neighbour in graph[node]:
            if not visited[neighbour] and capacity[node][neighbour] > 0:
                q.put(neighbour)
                print(neighbour)
                visited[neighbour] = True
                parent[neighbour] = node
    ####  final modificare
    print("Fluxul maxim:")
    return max_flow

print(edmonds_karp())