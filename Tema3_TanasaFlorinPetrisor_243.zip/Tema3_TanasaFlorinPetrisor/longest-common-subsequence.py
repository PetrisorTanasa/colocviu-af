class Solution:
    def longestCommonSubsequence(self, text1: str, text2: str) -> int:
        n = len(text1)
        m = len(text2)

        matrix = [[0]*(m+1) for x in range(n+1)]

        for l in range(1,n+1):
            for c in range(1,m+1):
                if text1[l-1] == text2[c-1]:
                    matrix[l][c] = 1+matrix[l-1][c-1]
                else:
                    matrix[l][c] = max(matrix[l-1][c],matrix[l][c-1])
        return matrix[n][m]