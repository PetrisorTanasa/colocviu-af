class Solution:
    def validArrangement(self, pairs: List[List[int]]) -> List[List[int]]:
        d = defaultdict(list)
        count = defaultdict(int)
        for i in pairs:
            d[i[0]].append(i[1])
            count[i[0]] += 1
            count[i[1]] -= 1
        
        start = pairs[0][0]
        for i in d.keys():
            if count[i] == 1:
                start = i
                break

        rasp = []
        def dfs(nod):
            while d[nod]:
                v = d[nod].pop()
                dfs(v)
                rasp.append([nod,v])
        dfs(start)
        return rasp[::-1]